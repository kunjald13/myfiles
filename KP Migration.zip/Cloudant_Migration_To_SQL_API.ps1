#Add-Type -AssemblyName System.Web
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType] 'Tls, Tls11, Tls12, Ssl3'
################################## User Inputs #############################################
<##>  $input_AppName = 'APP_NAME'
<##>  $input_CloudantUserName = 'CLOUDANT_USERNAME'
<##>  $input_CloudantPassword = 'CLOUDANT_PASSWORD'
<##>  $input_CloudantAccount = $input_CloudantUserName
<##>  $input_CloudantDatabase = 'CLOUDANT_DATABASE'
<##>  $input_BaseFolder = 'P:\psLocal'      #Should be existing path.
<##>  $input_DocsPerFile = 500
<##>  $input_PartialExec = 100      #Should be 100. Less than 100 used for testing ONLY.
<#    The input section below should be populated ONLY if Destination is Cosmos-Mongo API  #>

<##>  $input_ForMongoDb = $false       #Set to true if migrating to Mongo Db and populate details below
<##>  $input_mongoImportPath = 'P:\MongoDBTools\mongoimport'        #Existing Path to mongoimport tool
<##>  $input_mongoHostName = 'COSMOS_SERVER_NAME.mongo.cosmos.azure.com'     #Without https://
<##>  $input_mongoPort = 10255
<##>  $input_mongoDbName = 'COSMOS_DATABASE'        #Cosmos Database Name
<##>  $input_mongoCollection = 'COSMOS_COLLECTION'       #Cosmos Container Name
<##>  $input_mongoUsername = 'COSMOS_SERVER_NAME'    #Cosmos Server Name (without mongo.cosmos.azure.com)
<##>  $input_mongoPassword = 'COSMOS SECRET KEY'
################################## END User Inputs #############################################


$keyChunkSize = 50000
$dtStartCloudant = Get-Date
$appName = $input_AppName
$cldntUserName = $input_CloudantUserName
$cldntPassword = $input_CloudantPassword
$cldntDatabase = $input_CloudantDatabase
$cldntAccount  = $input_CloudantAccount
$DocsPerFile   = $input_DocsPerFile

$mongoImportPath = $input_mongoImportPath
$mongoHostName = $input_mongoHostName
$mongoPort = $input_mongoPort
$mongoDbName = $input_mongoDbName
$mongoCollection = $input_mongoCollection
$mongoUsername = $input_mongoUsername
$mongoPassword = $input_mongoPassword


#Cloudant Options
$cldntHasViews = $false
$dbName = $cldntDatabase -replace '\W',''

$baseFolder = $input_BaseFolder
$folderAppName = "${baseFolder}\${appName}"
$folderAppDBName = "${folderAppName}\${dbName}"
$fileExtn = "json"
$fileNumber = 0
$stg1Path = "$folderAppDBName\Stage1"
$stg2Path = "$folderAppDBName\Stage2"
$DDocsPath = "$folderAppDBName\DesignDocs"
$stg1BaseFileName = "stg1${dbName}"
$stg2BaseFileName = "stg2${dbName}"
$DDocsBaseFileName = "DD_${stg2BaseFileName}"
$reconFilePath = "$folderAppDBName\recon_${appName}_${dbName}.txt"
#$miReconFilePath = "$folderAppDBName\MongoImport_Recon_${appName}_${dbName}.txt"
$logFilePath = "$folderAppDBName\ExecutionLog.txt"
$logMsg = ''

$stg1Filename = ''
$stg2Filename = ''
$cldntCredential = (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $cldntUserName, ($cldntPassword | ConvertTo-SecureString -AsPlainText -Force ))
$logicalProcessorCount = (Get-ComputerInfo).CsNumberOfLogicalProcessors
$MaxThreads = $logicalProcessorCount * 2
$mongoImportThreads = $logicalProcessorCount - 1
#$mongoImportThreads = $MaxThreads
$reconS1Count = 0
$reconS2Count = 0
$reconDDCount = 0

function Write-myLog {
    Param (
        [Parameter(Mandatory=$true)][string]$File,
        [Parameter(Mandatory=$true)][string]$Value,
        [Parameter(Mandatory=$true)][bool]$onScreen
    )
    $dt = Get-Date -Format "yyyy-MM-dd HH:mm:ss.FFF"
    Add-Content -Path $File -Value "$dt $Value" -Encoding uTF8
    if ($onScreen -eq $true)
    {
        Write-Host $Value
    }
}

function Write-myError {
    Param (
    [Parameter(Mandatory=$true)][bool]$onScreen
    )
    $errMessage = "Error at line: $($error[0].InvocationInfo.Line)`n`  "
    $errMessage += "Error executing: $($error[0].InvocationInfo.ScriptLineNumber)`n` "
    $errMessage += "Error Message: $($error[0].Exception.Message)"

    Write-myLog -File $logFilePath -onScreen $true -Value $errMessage
}

#Function Invoke-Job {
$scriptBlkCreateFile = {
    param (
        [Parameter(Mandatory)][string] $uriStartKey,
        [Parameter(Mandatory)][PSCredential] $Credential,
        [Parameter(Mandatory)][bool] $hasViews,
        [Parameter(Mandatory)][string] $stg1File,
        [Parameter(Mandatory)][string] $stg2File,
        [Parameter(Mandatory)][string] $DDocsFile,
        [Parameter(Mandatory)][string] $reconFile
    )

    [Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType] 'Tls, Tls11, Tls12, Ssl3'
    $objApiJson = (Invoke-RestMethod -Uri $uriStartKey  -Credential $Credential).rows.doc
    
    if ($objApiJson -isnot [array]) {
        #if the database has only 1 document
        $objApiJson = @($objApiJson)
    }
    #$s1Json = $objJson | ConvertTo-Json -Depth 100
    Set-Content -Path $stg1File -Value (ConvertTo-Json -InputObject $objApiJson -Depth 100) -Encoding UTF8
    #$objApiJson = $s1Json | ConvertFrom-Json

    
    [System.Collections.ArrayList]$arrJson = [System.Collections.ArrayList]::new()
    [System.Collections.ArrayList]$arrDesignDocs = [System.Collections.ArrayList]::new()
    
    $stg1RecCount = $objApiJson.Count
    for ($i = 0; $i -lt $stg1RecCount; $i++) {

        if ($hasViews -eq $true){
            if ($objApiJson[$i]._id -like '_design/*'){
                [void]$arrDesignDocs.Add($objApiJson[$i])
                continue #goto next iteration; skip the remaining code in the loop.
            }
        }

        #################### Code to use if id already exists in the document ##############################
        if ($objApiJson[$i].PSObject.Properties.Name.Contains("id"))
        {
            $objApiJson[$i] | Add-Member -NotePropertyName "id2" -NotePropertyValue $objApiJson[$i].id
            $objApiJson[$i].id = $objApiJson[$i]._id
        }
        else
        {
            $objApiJson[$i] | Add-Member -NotePropertyName "id" -NotePropertyValue $objApiJson[$i]._id
        }

        $objApiJson[$i].PsObject.Properties.Remove("_id")

        $objApiJson[$i].PsObject.Properties.Remove("_rev")

        [void]$arrJson.Add($objApiJson[$i])
    }
    Clear-Variable 'objApiJson'
    $stg2RecCount = $arrJson.Count
    if ($stg2RecCount -gt 0){
        Set-Content -Path $stg2File -Value (ConvertTo-Json -InputObject $arrJson -Depth 100) -Encoding UTF8
    }
 
    $DDRecCount = $arrDesignDocs.Count
    if ($DDRecCount -gt 0){
        Set-Content -Path $DDocsFile -Value (ConvertTo-Json -InputObject $arrDesignDocs -Depth 100) -Encoding UTF8
    }

    $s1FileName = Split-Path $stg1File -Leaf
    $s2FileName = Split-Path $stg2File -Leaf
    $DDFileName = Split-Path $DDocsFile -Leaf

    # Create/Populate recon File
    $DDLine = ''
    if ($DDRecCount -gt 0){
        $DDLine = "$DDFileName|$DDRecCount"
    } else {
        $DDLine = '|'
    }

    $line = "${s1FileName}|${stg1RecCount}|${s2FileName}|${stg2RecCount}|$DDLine"

    #Add-Content -Path $reconFile -Value $line
    Write-Output $line
}
#################################### End Script Block##########################################################

#Function Invoke-MongoImportJob {
$scriptBlkMongoImport = {
    param (
        [Parameter(Mandatory)][string] $mngCmd,
        [Parameter(Mandatory)][string] $mngFilename,
        [Parameter(Mandatory)][string[]] $mngParams
    )
    [Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType] 'Tls, Tls11, Tls12, Ssl3'
    $Msg = ''
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo.UseShellExecute = $false
    $process.StartInfo.RedirectStandardOutput = $true
    $process.StartInfo.RedirectStandardError = $true
    $process.StartInfo.FileName = $mngCmd
    if ($mngParams) {$process.StartInfo.Arguments = $mngParams}

    [void]$process.Start()
    $StandardError = $process.StandardOutput.ReadToEnd()
    $StandardOutput = $process.StandardError.ReadToEnd()

    $Msg = $StandardOutput

    if ($StandardError.Length -gt 0)
    {
        $hasError = $true
        $Msg = $StandardError
    }
    Write-Output "$mngFilename|$hasError|$Msg"
}
############### Main Program Starts ###########################################################################

if ((Test-Path -Path $logFilePath -PathType Leaf) -eq $true){
    Remove-Item $logFilePath
}
$logMsg = "Execution Log for migration of App = $appName ; Database = $cldntDatabase on $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`r`n"
#Initialize Log file
[void](New-Item -Path $logFilePath -ItemType File -Value $logMsg -Force)

Write-myLog -File $logFilePath -onScreen $true -Value 'Begin folder processing'
try 
{
    #Create base folder path
    if (Test-Path -Path $stg1Path) {
        Write-myLog -File $logFilePath -onScreen $true -Value 'Deleting files from stage1'
        Get-ChildItem -Path $stg1Path -Include "${stg1BaseFileName}*.json" -Recurse | Remove-Item
    }
    else {
        [void](New-Item -ItemType Directory -Path $stg1Path)
    }

    if (Test-Path -Path $stg2Path) {
        Write-myLog -File $logFilePath -onScreen $true -Value 'Deleting files from stage2'
        Get-ChildItem -Path $stg2Path -Include "${stg2BaseFileName}*.json" -Recurse | Remove-Item
    }
    else {
        [void](New-Item -ItemType Directory -Path $stg2Path)
    }

    if (Test-Path -Path $DDocsPath) {
        Write-myLog -File $logFilePath -onScreen $true -Value 'Deleting files from DesignDocs'
        Get-ChildItem -Path $DDocsPath -Include "${DDocsBaseFileName}*.json" -Recurse | Remove-Item
    }
    else {
        [void](New-Item -ItemType Directory -Path $DDocsPath)
    }

    if ((Test-Path -Path $reconFilePath -PathType Leaf) -eq $true){
        #$arrAllKeys = Get-Content -Path $appIndexFileName
        Remove-Item $reconFilePath
    }

<#
    if ((Test-Path -Path $miReconFilePath -PathType Leaf) -eq $true){
        #$arrAllKeys = Get-Content -Path $appIndexFileName
        Remove-Item $miReconFilePath
    }
#>

    Write-myLog -File $logFilePath -onScreen $true -Value 'Processing folders completed.'
} catch {
    Write-myError -onScreen $true
    Write-myLog -File $logFilePath -onScreen $true -Value 'Error processing folders.`n`Terminating Script.'
    Exit
}

# ########### Test connection to Source ##########################################
$noOfDocs = 0
$cldntdbUri = "https://$cldntAccount.cloudant.com/$cldntDatabase"
    try 
    {
        $noOfDocs = (Invoke-RestMethod -Uri "${cldntdbUri}" -Credential $cldntCredential).doc_count
        Write-myLog -File $logFilePath -onScreen $true -Value "Cloudant Test Connection Success."
        Write-myLog -File $logFilePath -onScreen $true -Value "No of Records in Cloudant = $noOfDocs"
    }
    catch {
        Write-myError -onScreen $true
        Write-myLog -File $logFilePath -onScreen $true -Value "Cloudant Test Connection Failed.`n`Terminating Script."
        Exit
    }

###################################### Check for _Design documents ####################################
    try 
    {
        $ddocCount = 0
        $ddocCount = (Invoke-RestMethod -Uri "${cldntdbUri}/_design_docs" -Credential $cldntCredential).total_rows

        if ($ddocCount -gt 0)
        {
            $cldntHasViews = $true
        }
        Write-myLog -File $logFilePath -onScreen $true -Value "Design documents count: $ddocCount" 
    } catch {
        Write-myError -onScreen $true
        Write-myLog -File $logFilePath -onScreen $true -Value 'Design Doc API call failed.`n`Terminating Script.'
    }

    try 
    {     
        Write-myLog -File $logFilePath -onScreen $true -Value 'Keys Processing start.'
        $arrAllKeys =  New-Object -TypeName System.Collections.ArrayList
        $qStartKeys = [System.Collections.Queue]::Synchronized((New-Object System.Collections.Queue))

        $appIndexFileName = "$folderAppDBName\Index_${appName}_${dbName}.txt"
        if ((Test-Path -Path $appIndexFileName -PathType Leaf) -eq $true) {
            #$arrAllKeys = Get-Content -Path $appIndexFileName
            Remove-Item $appIndexFileName
        }

        $nullChar = [uri]::EscapeUriString([System.Web.HttpUtility]::UrlEncode([char]0x0000))
        $keysProcessed = 0
        $startKey = ''
        $allKeysDownloadProgress = 0
        $ProgressIdKeys = Get-Random
        while ($keysProcessed -lt $noOfDocs) {
            $url = "$cldntdbUri/_all_docs?limit=$keyChunkSize$startKey"
            $apiKeyResult = (Invoke-RestMethod -Uri $url -Credential $cldntCredential).rows.id
            $startKey = '&startkey=' + '"' + $apiKeyResult[-1] + $nullChar + '"'
            Add-Content -Path $appIndexFileName -Value $apiKeyResult -Encoding UTF8
            #$key = $apiKeyResult[0].id
            #$qStartKeys.Enqueue($key)
            $keysProcessed += $apiKeyResult.Count
            $allKeysDownloadProgress = [Math]::Round(($keysProcessed) * 100/ $noOfDocs,2)
            Write-Progress -Activity "Download Keys from Cloudant" -Status "$keysProcessed out of $noOfDocs. $allKeysDownloadProgress %" -Id $ProgressIdKeys -PercentComplete $allKeysDownloadProgress
        }
        $startKey = ''
        $arrAllKeys = [System.IO.File]::ReadAllLines($appIndexFileName,[System.Text.Encoding]::UTF8)
        Write-myLog -File $logFilePath -onScreen $true -Value 'Keys Processing completed.'
        Write-myLog -File $logFilePath -onScreen $true -Value "Keys Processed = ${keysProcessed}"

        

        #$arrAllKeys.AddRange((Invoke-RestMethod -Uri "$cldntdbUri/_all_docs" -Credential $cldntCredential).rows.id)
        #Set-Content -Path $appIndexFileName -Value $arrAllKeys -Encoding UTF8
        #Write-myLog -File $logFilePath -onScreen $true -Value "Source Count = $($arrAllKeys.Count)"
        Write-myLog -File $logFilePath -onScreen $true -Value 'Queue loading Started'

        [int]$srcRecCount = $arrAllKeys.Count
        $srcRecCount = [System.Math]::Round($arrAllKeys.Count * ($input_PartialExec/100),0)

        
        for ($i = 0; $i -lt $srcRecCount; $i += $DocsPerFile) {
            $qStartKeys.Enqueue($arrAllKeys[$i])
        }
        Clear-Variable 'arrAllKeys'
        Write-myLog -File $logFilePath -onScreen $true -Value 'Queue loading completed'
        Write-myLog -File $logFilePath -onScreen $true -Value 'Keys processing completed.'
    } catch {
        Write-myError -onScreen $true
        Write-myLog -File $logFilePath -onScreen $true -Value 'Errors in Keys processing.`n`Terminating Script.'
        Exit
    }
        $queueCount = $qStartKeys.Count
        $completedCount = 0
        $ProgressId = Get-Random
        $runningCount = 0
        $startKey = ''
        $baseJobName = "job${appName}_${dbName}"
        $failedCount = 0
        $fileNumber = 0
    try 
    {
        Write-myLog -File $logFilePath -onScreen $true -Value 'Start Multi-threaded Jobs.'
        $x = @(Get-Job -Name "${baseJobName}*") 
        $x | Remove-Job
        while (($qStartKeys.Count + $runningCount) -gt 0) 
        {
            if (($runningCount -lt $MaxThreads) -and ($qStartKeys.Count -gt 0)) 
            {
                $startKey = $qStartKeys.Peek().ToString()
                $fileNumber++
                $cldntStartKeyUri = "$cldntdbUri/_all_docs?include_docs=true&limit=$DocsPerFile&startkey=""$startKey"""
                $stg1Filename = "${stg1Path}\${stg1BaseFileName}${fileNumber}.${fileExtn}"
                $stg2Filename = "${stg2Path}\${stg2BaseFileName}${fileNumber}.${fileExtn}"
                $DDocsFilename = "${DDocsPath}\${DDocsBaseFileName}${fileNumber}.${fileExtn}"
                $jobName = "${baseJobName}${fileNumber}"
                [void]$qStartKeys.Dequeue()

                $jobDefinition = "$jobName|$cldntStartKeyUri|$cldntCredential|$cldntHasViews|$stg1Filename|$stg2Filename|$DDocsFilename"
                
                [void](Start-Job -Name $jobName -ScriptBlock $scriptBlkCreateFile -ArgumentList $cldntStartKeyUri, $cldntCredential, $cldntHasViews, $stg1Filename, $stg2Filename, $DDocsFilename, $reconFilePath)
                #$r = Invoke-Job $cldntStartKeyUri $cldntCredential $cldntHasViews $stg1Filename $stg2Filename $DDocsFilename $reconFilePath
                Write-myLog -File $logFilePath -onScreen $false -Value "Start Job:$jobDefinition"
                
            }

            #Status
            $allJobs = @(Get-Job -Name "${baseJobName}*") #| Wait-Job -Any

            $runningJobs = @($allJobs | Where-Object { ($_.State -eq 'Running') })
            $runningCount = $runningJobs.Count

            $completedJobs = @($allJobs | Where-Object { ($_.State -eq 'Completed') })
            $failedJobs = @($allJobs | Where-Object { ($_.State -eq 'Failed') })
            

            $completedCount += $completedJobs.Count
            $failedCount += $failedJobs.Count

            foreach ($item in $completedJobs) 
            {
                $jobOP = Receive-Job $item
                $arr = $jobOP.Split("|")
                $reconS1Count += $arr[1]
                $reconS2Count += $arr[3]
                $reconDDCount += $arr[5]
                Add-Content -Path $reconFilePath -Value $jobOP -Encoding UTF8
            }
            $completedJobs | Remove-Job 
            $failedJobs | Remove-Job

            $percentComplete = ([Math]::Round((($completedCount + $failedCount) / $queueCount) * 100))
            Write-Progress -Activity "Download from Cloudant to Stage2" -Status "Total $queueCount | Queued $($queueCount - $completedCount - $runningCount - $failedCount) | Running $($runningCount) | Completed $($completedCount) | Failed $($failedCount) | completed(%) $($percentComplete)" -Id $ProgressId -PercentComplete $percentComplete
        }
        Add-Content -Path $reconFilePath -Value "Source Count = $srcRecCount|Stage1 Count = $reconS1Count|Stage2 Count = $reconS2Count|Stage2 Design Document Count = $reconDDCount"
        $dtEndCloudant = Get-Date

        Write-myLog -File $logFilePath -onScreen $true -Value "Download from source:Completed"
        Write-myLog -File $logFilePath -onScreen $true -Value "Total $queueCount | Queued $($queueCount - $completedCount - $runningCount) | Running $($runningCount) | Completed $($completedCount) | Failed $($failedCount) | completed(%) $($percentComplete)"
        Write-myLog -File $logFilePath -onScreen $true -Value "$srcRecCount|$reconS1Count|$reconS2Count|$reconDDCount"
        Write-myLog -File $logFilePath -onScreen $true -Value ' '
        Write-myLog -File $logFilePath -onScreen $true -Value "Reconciliation file created at $reconFilePath"
        Write-myLog -File $logFilePath -onScreen $true -Value ' '
        
    }
    Catch {
        Write-myError -onScreen $true
        Write-myLog -File $logFilePath -onScreen $true -Value 'Error during Job initiation. Script will continue.'
    }

    try 
    {

        $miTotalFileCount = 0

        [decimal]$miMongoProgress = 0 
        if ($input_ForMongoDb -eq $true) 
        {
            Write-myLog -File $logFilePath -onScreen $true -Value 'Starting Cosmos Insert'
            $qStg2Files = [System.Collections.Queue]::Synchronized((New-Object System.Collections.Queue))
            [string[]]$arrStg2Files = [System.IO.Directory]::GetFiles($stg2Path,"$stg2BaseFileName*.${fileExtn}")
            $miTotalFileCount = $arrStg2Files.Count

            for ($i = 0; $i -lt $miTotalFileCount; $i++) {
                $qStg2Files.Enqueue($arrStg2Files[$i])
            }

            $miRunningCount = 0
            $miQueueCount = $qStg2Files.Count
            $miFileCounter = 0
            $miBaseJobName = "jobMngImprt${appName}_${dbName}"
            $miRunningCount = 0
            $miCompletedCount = 0
            $miFailedCount = 0
            $miReceiveCounter = 0
            $miInsertHadError = $false
            $miInsertMessage = ''
            $miReconMessage = ''

            $miProgressId = Get-Random
            $y = @(Get-Job -Name "${miBaseJobName}*") 
            $y | Remove-Job

            while (($qStg2Files.Count + $miRunningCount) -gt 0)
            {
                if (($miRunningCount -lt $mongoImportThreads) -and ($qStg2Files.Count -gt 0)) 
                {
                    $jsonFileName = Split-Path -Path $qStg2Files.Peek().ToString() -Leaf
                    
                    #$uri = "`"mongodb://${mongoUsername}:${mongoPassword}@${mongoHostName}:${mongoPort}/?ssl=true&connect=direct`""
                    $uri = "`"mongodb://${mongoUsername}:${mongoPassword}@${mongoHostName}:${mongoPort}/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@${mongoUsername}@`""
                    $params = "--uri", $uri, "--db",${mongoDbName}, "--collection",${mongoCollection}, "--file",$qStg2Files.Dequeue().ToString(), "--writeConcern", "{w:0}", "--type", "json", "--tlsInsecure", "--jsonArray", "--numInsertionWorkers", 2, "--bypassDocumentValidation"
                    #$params = "--uri", $uri, "--db",${mongoDbName}, "--collection",${mongoCollection}, "--file",$qStg2Files.Dequeue().ToString(), "--writeConcern", "{w:'majority'}", "--type", "json", "--sslAllowInvalidCertificates", "--sslAllowInvalidHostnames", "--jsonArray", "--numInsertionWorkers", 2, "--bypassDocumentValidation"
                    Write-Host $params
                    Write-Host ''

                    $miFileCounter++
                    $miJobName = "${miBaseJobName}${miFileCounter}"
                    
                    [void](Start-Job -Name $mijobName -ScriptBlock $scriptBlkMongoImport -ArgumentList $mongoImportPath, $jsonFileName, $params)
                    #$j = Invoke-MongoImportJob $mongoImportPath $jsonFileName $params
                    #Write-Host $mongoImportPath
                    #Write-Host $params

                    #& $mongoImportPath $params
                }
                #Status
                $miAllJobs = @(Get-Job -Name "${miBaseJobName}*")

                $miRunningJobs = @($miAllJobs | Where-Object { ($_.State -eq 'Running') })
                $miRunningCount = $miRunningJobs.Count

                $miCompletedJobs = @($miAllJobs | Where-Object { ($_.State -eq 'Completed') })
                $miFailedJobs = @($miAllJobs | Where-Object { ($_.State -eq 'Failed') })
                

                $miCompletedCount += $miCompletedJobs.Count
                $miFailedCount += $miFailedJobs.Count
                
                $miMongoProgress = ([Math]::Round((($miCompletedCount + $miFailedCount) / $miQueueCount) * 100))

                foreach ($miItem in $miCompletedJobs) 
                {
                    $miJobOP = Receive-Job $miItem
                    $miArr = $miJobOP.Split("|")
                    Write-myLog -File $logFilePath -onScreen $false -Value "File = $($miArr[0])"
                    Write-myLog -File $logFilePath -onScreen $false -Value "$($miArr[2])"
                    $miReceiveCounter++
                    Write-myLog -File $logFilePath -onScreen $false -Value "Completed $miReceiveCounter of $miQueueCount file. $miMongoProgress %"
                    Write-myLog -File $logFilePath -onScreen $false -Value '---------------------------------------------------------------------------------------------------'

                }

                $miCompletedJobs | Remove-Job
                $miFailedJobs | Remove-Job
                
                Write-Progress -Activity "Inserting into Cosmos" -Status "Total $miQueueCount | Queued $($miQueueCount - $miCompletedCount - $miRunningCount - $miFailedCount) | Running $($miRunningCount) | Completed $($miCompletedCount) | Failed $($miFailedCount) | completed(%) $($miMongoProgress)" -Id $miProgressId -PercentComplete $miMongoProgress

            }
            Write-myLog -File $logFilePath -onScreen $true -Value 'Completed Cosmos Insert'
        }
    } 
    catch
    {
        Write-myError -onScreen $true
        Write-myLog -File $logFilePath -onScreen $true -Value 'Terminating the script.'
        
    }
$dtEndCosmos = Get-Date
Write-myLog -File $logFilePath -onScreen $true -Value ' '
Write-myLog -File $logFilePath -onScreen $true -Value "Upload to Cosmos completed at $($dtEndCosmos.ToString('yyyy-MM-dd hh:mm:ss'))"


if ($input_ForMongoDb -eq $true)
{
    $tsCloudant = New-TimeSpan -Start $dtStartCloudant -End $dtEndCloudant
    Write-myLog -File $logFilePath -onScreen $true -Value "Cloudant to Stage2 - Time taken: $($tsCloudant.Hours):$($tsCloudant.Minutes):$($tsCloudant.Seconds)"
    $tsCosmos = New-TimeSpan -Start $dtEndCloudant -End $dtEndCosmos
    Write-myLog -File $logFilePath -onScreen $true -Value "Stage2 to CosmosDB - Time taken: $($tsCosmos.Hours):$($tsCosmos.Minutes):$($tsCosmos.Seconds)"
    $tsTotal = New-TimeSpan -Start $dtStartCloudant -End $dtEndCosmos
    Write-myLog -File $logFilePath -onScreen $true -Value "Grand Total - Time taken: $($tsTotal.Hours):$($tsTotal.Minutes):$($tsTotal.Seconds)"
}
else 
{
    $tsCloudant = New-TimeSpan -Start $dtStartCloudant -End $dtEndCloudant
    Write-myLog -File $logFilePath -onScreen $true -Value "Cloudant to Stage2 - Time taken: $($tsCloudant.Hours):$($tsCloudant.Minutes):$($tsCloudant.Seconds)"
    Write-myLog -File $logFilePath -onScreen $true -Value "Grand Total - Time taken: $($tsCloudant.Hours):$($tsCloudant.Minutes):$($tsCloudant.Seconds)"
}


Write-myLog -File $logFilePath -onScreen $true -Value "----------------- Migration Completed. -----------------"
Read-Host "Press any key to exit .."
Exit

#end

