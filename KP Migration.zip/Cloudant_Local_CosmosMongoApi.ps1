Add-Type -AssemblyName System.Web

#Cloudant Options
$cldntUserName = 'f64b22ee-7a34-4c64-b220-9a595e3bbc50-bluemix'
$cldntPassword = 'd4e076f57046e09adccfd509638ec5f7120737ce4d1ae0ee71e751c1af2ad5a0'
$cldntAccount = $cldntUserName
$cldntDatabase = 'mdc'
#File Options
$basefileName = "${cldntDatabase}" -replace '\W','' -replace '_',''
$stg1Filename = "stg1${basefileName}_"
$stg2Filename = "stg2${basefileName}_"
$fileExtn = "json"
$fileNumber = 0
$recordsPerFile = 500
$stg1Path = "C:\psLocal\Stage1"
$stg2Path = "C:\psLocal\Stage2"

#MongoImport Path
$mongoImportPath = 'C:\Users\a342544\Desktop\MDC Azure\MongoDbTools\bin\mongoimport'
$mongoHostName = 'kpcsdbmomiqauws2mdc2.mongo.cosmos.azure.com'
$mongoPort = 10255
$mongoDbName = 'dbMDCal'
$mongoCollection = 'cMDCal'
$mongoUsername = 'kpcsdbmomiqauws2mdc2'
$mongoPassword = 'I9qBH1lGtyibFzXJFUHABbQ7iWzFdzE98OBxDA2G7wP1pipbfeBjZwXLWreVvzt1JScJKwuo9AZZ70zzAOyyDw=='

#Other Options
[bool] $cldntHasViews = $true
$arrStg2Files =  New-Object -TypeName System.Collections.ArrayList

#Main Program
$nullChar = [uri]::EscapeUriString([System.Web.HttpUtility]::UrlEncode([char]0x0000))
$startKey = ""
$dbUri = "https://$cldntAccount.cloudant.com/$cldntDatabase"

#Create PSCredential OBject to store uname and pwd
$Credential = (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $cldntUserName,  ($cldntPassword | ConvertTo-SecureString -AsPlainText -Force ))

#Create base folder path
if (Test-Path -Path $stg1Path) {
    Write-Host 'Deleting files from stage1'
    Get-ChildItem -Path $stg1Path -Include "${stg1FileName}*.json" -Recurse | Remove-Item
}
else {
    New-Item -ItemType Directory -Path $stg1Path
}

if (Test-Path -Path $stg2Path) {
    Write-Host 'Deleting files from stage2'
    Get-ChildItem -Path $stg2Path -Include "${stg2FileName}*.json" -Recurse | Remove-Item
}
else {
    New-Item -ItemType Directory -Path $stg2Path
}


#Get Database Properties including doc_count
$dbResult = Invoke-RestMethod -Uri $dbUri -Credential $Credential
$totalRows = $dbResult.doc_count

$recordsProcessed = 0
$recordsInCurentFile = 0

while ($recordsProcessed -lt $totalRows) {
    #StartKey will be blank; Get first X records
    #$dtUriStart = Get-Date
    $uri = "$dbUri/_all_docs?include_docs=true&limit=$recordsPerFile$startKey"
    $apiResult = Invoke-RestMethod -Uri $Uri -Credential $Credential
    #$dtUriEnd = Get-Date
    #$tsUri = New-TimeSpan -Start $dtUriStart -End $dtUriEnd

    #$startKey = '&startkey=' + [System.Web.HttpUtility]::UrlEncode($apiResult.rows.doc[-1]._id) # + $nullChar
    # Append url encoded Null character to the _id property of last document.
    # During first iteration $startKey will be initialized
    $startKey = '&startkey=' + '"' + $apiResult.rows.doc[-1]._id + $nullChar + '"' 
    
    $fileNumber++   # Increment the file counter

    # Write the documents to a file.
    $s1Json = $apiResult.rows.doc | ConvertTo-Json -Depth 100
    Clear-Variable 'apiResult'

    #Write to File
    Set-Content -Path "${stg1Path}\${stg1Filename}${fileNumber}.${fileExtn}" -Value $s1Json -Encoding UTF8

    $s1ObjJson = $s1Json | ConvertFrom-Json

    if ($s1ObjJson -isnot [array])  #if the database has only 1 document
    {
        $s1ObjJson = @($s1Json | ConvertFrom-Json)
    }
    
    Clear-Variable 's1Json'

    $recordsInCurentFile = $s1ObjJson.Length
    if ($cldntHasViews -eq $true) {
        $s1ObjJson = $s1ObjJson | Where-Object { $_._id -notlike "_design/*"}
    } 

    for ($i = 0; $i -lt $s1ObjJson.Length; $i++)
    {
        #################### Code to use if id already exists in the document ##############################
        # $s1ObjJson[$i] | Add-Member -NotePropertyName "id2" -NotePropertyValue $s1ObjJson[$i].id
        # $s1ObjJson[$i].id = $(New-Guid)
        # ##################################################################################################
        # $s1ObjJson[$i] | Add-Member -NotePropertyName "id" -NotePropertyValue $(New-Guid)
        $s1ObjJson[$i].PsObject.Properties.Remove("_rev")
    }
    $s2Json = $s1ObjJson | ConvertTo-Json -Depth 100
    
    Set-Content -Path "${stg2Path}\${stg2Filename}${fileNumber}.${fileExtn}" -Value $s2Json -Encoding UTF8
    [void]$arrStg2Files.Add("${stg2Path}\${stg2Filename}${fileNumber}.${fileExtn}")

    Clear-Variable 's1ObjJson'
    Clear-Variable 's2Json'

    #$apiResult.rows.doc | ConvertTo-Json -Depth 100| Out-File "$outFolder$fileName$fileNumber.$fileExtn" -Encoding utf8

    $recordsProcessed += $recordsInCurentFile    
    
    #Write-Host "${fileNumber},${recordsProcessed},${totalRows}"
    $progressPercentage = ([Math]::Round(($recordsProcessed/$totalRows) * 100,2))
    Write-Host "File number = ${fileNumber}; Proccessed ${recordsProcessed}/${totalRows}; Progress=${progressPercentage}%"
}

$mongoImportCommand = ''

for ($i = 0; $i -lt $arrStg2Files.Count; $i++) {
    #$mongoImportCommand = "'${mongoImportPath} --host ${mongoHostName} --port ${mongoPort}  --file $($_.FullName) --db ${mongoDbName} --collection ${mongoCollection} -u ${mongoUsername} -p $mongoPassword --ssl --writeConcern {w:0} --type json --tlsInsecure --jsonArray'"
    #$params = "--host", ${mongoHostName} ,"--port", ${mongoPort} ,"--file", $($_.FullName) ,"--db", ${mongoDbName}, "--collection" ,${mongoCollection}, "-u", ${mongoUsername}, "-p", $mongoPassword , "--writeConcern", "{w:0}", "--type", "json", "--jsonArray","--ssl"
    $uri = "`"mongodb://${mongoUsername}:${mongoPassword}@${mongoHostName}:${mongoPort}/?ssl=true&connect=direct`""
    #Write-Host $uri
    $params = "--uri", $uri, "--db",${mongoDbName}, "--collection",${mongoCollection}, "--file", $arrStg2Files[$i] , "--writeConcern", "{w:0}", "--type", "json", "--tlsInsecure", "--jsonArray" #, "--quiet"
    Write-Host "Uploading file $($arrStg2Files[$i])"

    & $mongoImportPath $params
}

Write-Host "End."
