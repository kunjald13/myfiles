Add-Type -AssemblyName System.Web
Function Get-AuthHeader{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $Verb,
        [Parameter(Mandatory)][AllowEmptyString()][string] $ResourceId,
        [Parameter(Mandatory)][string] $ResourceType,
        [Parameter(Mandatory)][string] $Date,
        [Parameter(Mandatory)][string] $MasterKey,
    	[Parameter(Mandatory)][String] $KeyType,
        [Parameter(Mandatory)][String] $TokenVersion
    )
    
    $hmacSha256 = New-Object System.Security.Cryptography.HMACSHA256
    $hmacSha256.Key = [System.Convert]::FromBase64String($MasterKey)
 
    If ($ResourceId -eq $ResourceType) {
        $ResourceId = ""
    }
 
    $payLoad = "$($Verb.ToLowerInvariant())`n$($ResourceType.ToLowerInvariant())`n$ResourceId`n$($Date.ToLowerInvariant())`n`n"
    $hashPayLoad = $hmacSha256.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($payLoad))
    $signature = [System.Convert]::ToBase64String($hashPayLoad)
 
    [System.Web.HttpUtility]::UrlEncode("type=$keyType&ver=$tokenVersion&sig=$signature")

    <#
    $keyBytes = [System.Convert]::FromBase64String($MasterKey)
    $sigCleartext = @($Verb.ToLower() + "`n" + $ResourceType.ToLower() + "`n" + $ResourceId + "`n" + $Date.ToString().ToLower() + "`n" + "" + "`n")
    Write-Host "sigCleartext = " $sigCleartext
    $bytesSigClear = [Text.Encoding]::UTF8.GetBytes($sigCleartext)
    $hmacsha = new-object -TypeName System.Security.Cryptography.HMACSHA256 -ArgumentList (, $keyBytes)
    $hash = $hmacsha.ComputeHash($bytesSigClear) 
    $signature = [System.Convert]::ToBase64String($hash)
    $key = [System.Web.HttpUtility]::UrlEncode('type='+$KeyType+'&ver='+$TokenVersion+'&sig=' + $signature)
    #>
}

Function Get-CosmosSQLDatabase{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $EndPoint,
        [Parameter(Mandatory)][string] $DatabaseId,
        [Parameter(Mandatory)][string] $MasterKey,
        [Parameter(Mandatory)][string] $KeyType,
        [Switch] $AllDdatabases
    )

    $dbResourceLink = "dbs"
    if ($AllDdatabases -eq $false)
    {
        $dbResourceLink += "/$DatabaseId"
    }
    $resourceType = "dbs"
    $contentType = "application/json"
    $verb = "GET"
    $date = Get-Date
    $utcDate = $date.ToUniversalTime()
    $xDate = $utcDate.ToString('r', [System.Globalization.CultureInfo]::InvariantCulture)
    $requestUri = "$EndPoint$dbResourceLink"
    $authHeader = Get-AuthHeader -Verb $verb -ResourceId $dbResourceLink -ResourceType $resourceType -Date $xDate -MasterKey $MasterKey -KeyType $KeyType -TokenVersion "1.0"
    $headers = @{
        "authorization"         = "$authHeader";
        "x-ms-version"          = "2018-12-31";
        "Cache-Control"         = "no-cache";
        "x-ms-date"             = "$xDate";
        "Accept"                = "$contentType";
        "User-Agent"            = "KP-Bluemix2Azure"
    }

    try {
        $result = Invoke-RestMethod -Uri $requestUri -Headers $headers -Method $verb -ContentType $contentType
        Write-Host "Database "$DatabaseId" Read"
        Write-Host ConvertTo-Json -InputObject $result -Depth 100
        return $result
    }
    catch{
    Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
    Write-Host "Exception Message:" $_.Exception.Message
    return $_.Exception.Message;
    }
}
Function New-CosmosSQLDatabase{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $EndPoint,
        [Parameter(Mandatory)][string] $DatabaseId,
        [Parameter(Mandatory)][string] $MasterKey,
        [Parameter(Mandatory)][string] $KeyType
    )
    $dbResourceLink = "dbs"
    $resourceType = "dbs"
    $contentType = "application/json"
    $verb = "POST"
    $date = Get-Date
    $utcDate = $date.ToUniversalTime()
    $xDate = $utcDate.ToString('r', [System.Globalization.CultureInfo]::InvariantCulture)
    $resourceId = ""
    $requestUri = "$EndPoint$dbResourceLink"
    $authHeader = Get-AuthHeader -Verb $verb -ResourceId $resourceId -ResourceType $resourceType -Date $xDate -MasterKey $MasterKey -KeyType $KeyType -TokenVersion "1.0"
    $headers = @{
        "authorization"         = "$authHeader";
        "x-ms-version"          = "2018-12-31";
        "Cache-Control"         = "no-cache";
        "x-ms-date"             = "$xDate";
        "Accept"                = "$contentType";
        "User-Agent"            = "KP-Bluemix2Azure"
    }

    $databaseDefinition = @"
    {
        "id" : "$DatabaseId" 
    }
"@

    try {
        $result = Invoke-RestMethod -Uri $requestUri -Headers $headers -Method $verb -ContentType $contentType -Body $databaseDefinition
        Write-Host "Database "$DatabaseId" created | "
        Write-Host ConvertTo-Json -InputObject $result -Depth 100
        return $result
        
    }
    catch{
    Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
    Write-Host "Exception Message:" $_.Exception.Message
    return $_.Exception.Message;
    }
}

Function Remove-CosmosSQLDatabase{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $EndPoint,
        [Parameter(Mandatory)][string] $DatabaseId,
        [Parameter(Mandatory)][string] $MasterKey,
        [Parameter(Mandatory)][string] $KeyType
    )
    $dbResourceLink = "dbs/$DatabaseId"
    $dbResourceId = $dbResourceLink
    $resourceType = "dbs"
    $contentType = "application/json"
    $verb = "DELETE"
    $date = Get-Date
    $utcDate = $date.ToUniversalTime()
    $xDate = $utcDate.ToString('r', [System.Globalization.CultureInfo]::InvariantCulture)
    $requestUri = "$EndPoint$dbResourceLink"

    $authKey = Get-AuthHeader -Verb $verb -ResourceId $dbResourceId -ResourceType $ResourceType -Date $xDate -MasterKey $MasterKey -KeyType $KeyType -TokenVersion "1.0"

    $header = @{
        "authorization"         = "$authKey";
        "x-ms-version"          = "2018-12-31";
        "Cache-Control"         = "no-cache";
        "x-ms-date"             = "$xDate";
        "Accept"                = "application/json";
        "User-Agent"            = "PowerShell-RestApi-Samples"
    }

    try {
        $result = Invoke-RestMethod -Uri $requestUri -Headers $header -Method $verb -ContentType $contentType
        Write-Host $databaseId " database deleted"
        Write-Host "DeleteDBSuccess"
        return $result
    }
    catch {
        Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
        Write-Host "Exception Message:" $_.Exception.Message
        return $_.Exception.Message;
    }
}


Function New-CosmosSQLContainer{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $EndPoint,
        [Parameter(Mandatory)][string] $DatabaseId,
        [Parameter(Mandatory)][string] $ContainerId,
        [Parameter(Mandatory)][string] $PartitionKey,
        [Parameter(Mandatory)][string] $MasterKey,
        [Parameter(Mandatory)][string] $KeyType,
        [Parameter(Mandatory=$false)] $ttlValue = $null,
        [Parameter(Mandatory=$false)][string] $ResponseBody
    )

    $resourceLink = "dbs/$DatabaseId/colls"
    $resourceId = "dbs/$DatabaseId"
    $resourceType = "colls"
    $contentType = "application/json"
    $verb = "POST"
    $date = Get-Date
    $utcDate = $date.ToUniversalTime()
    $xDate = $utcDate.ToString('r', [System.Globalization.CultureInfo]::InvariantCulture)
    $requestUri = "$EndPoint$resourceLink"

    try {
    $authkey = Get-AuthHeader -Verb $verb -ResourceId $resourceId -ResourceType $resourceType -Date $xDate -MasterKey $MasterKey -KeyType $KeyType -TokenVersion "1.0"

    $header = @{
        "authorization"         = "$authKey";
        "x-ms-version"          = "2018-12-31";
        "Cache-Control"         = "no-cache";
        "x-ms-date"             = "$xDate";
        "Accept"                = "application/json";
        "User-Agent"            = "PowerShell-RestApi-Samples"
    }
    $temp = @"
    {
        "id": "$ContainerId",
        "partitionKey": {"paths":["$PartitionKey"]}
    }
"@
    $obj = ConvertFrom-Json -InputObject $temp
    if ($null -ne $ttlValue)
    {
        $obj | Add-Member -MemberType NoteProperty -Name 'defaultTtl' -Value $ttlValue
    }

    $temp = ConvertTo-Json -InputObject $obj -Depth 100
    $body = ""
    if ($PSBoundParameters.ContainsKey('ResponseBody'))
    {
        $body = $ResponseBody
    } else {
        $body = $temp
    }

    #Write-Host $ContainerDefinition | ConvertTo-Json
    $result = Invoke-RestMethod -Uri $requestUri -Headers $header -Method $verb -ContentType $contentType -Body $body
    Write-Host "Container $ContainerId created."
    Write-Host "CreateContainerSuccess"
    return $result
    }
    catch{
        Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
        Write-Host "Exception Message:" $_.Exception.Message
        return $_.Exception.Message;  
    }

}

Function Remove-CosmosSQLContainer{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $EndPoint,
        [Parameter(Mandatory)][string] $DatabaseId,
        [Parameter(Mandatory)][string] $ContainerId,
        [Parameter(Mandatory)][string] $MasterKey,
        [Parameter(Mandatory)][string] $KeyType
    )

    $resourceLink = "dbs/$DatabaseId/colls/$ContainerId"
    $resourceType = "colls"
    $contentType = "application/json"
    $verb = "DELETE"
    $date = Get-Date
    $utcDate = $date.ToUniversalTime()
    $xDate = $utcDate.ToString('r', [System.Globalization.CultureInfo]::InvariantCulture)
    $requestUri = "$EndPoint$resourceLink"

    try {
    $authkey = Get-AuthHeader -Verb $verb -ResourceId $resourceLink -ResourceType $resourceType -Date $xDate -MasterKey $MasterKey -KeyType $KeyType -TokenVersion "1.0"

    $header = @{
        "authorization"         = "$authKey";
        "x-ms-version"          = "2018-12-31";
        "Cache-Control"         = "no-cache";
        "x-ms-date"             = "$xDate";
        "Accept"                = "application/json";
        "User-Agent"            = "PowerShell-RestApi-Samples"
    }

    $result = Invoke-RestMethod -Uri $requestUri -Headers $header -Method $verb -ContentType $contentType
    Write-Host "Container $ContainerId Deleted."
    Write-Host "RemoveContainerSuccess"
    return $result
    }
    catch{
        Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
        Write-Host "Exception Message:" $_.Exception.Message
        return $_.Exception.Message;  
    }
}


Function Get-CosmosSQLContainer{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $EndPoint,
        [Parameter(Mandatory)][string] $DatabaseId,
        [Parameter(Mandatory)][string] $ContainerId,
        [Parameter(Mandatory)][string] $MasterKey,
        [Parameter(Mandatory)][string] $KeyType
    )
    $resourceLink = "dbs/$DatabaseId/colls/$ContainerId"
    $resourceType = "colls"
    $contentType = "application/json"
    $verb = "GET"
    $date = Get-Date
    $utcDate = $date.ToUniversalTime()
    $xDate = $utcDate.ToString('r', [System.Globalization.CultureInfo]::InvariantCulture)
    $requestUri = "$EndPoint$resourceLink"

    try {
    $authkey = Get-AuthHeader -Verb $verb -ResourceId $resourceLink -ResourceType $resourceType -Date $xDate -MasterKey $MasterKey -KeyType $KeyType -TokenVersion "1.0"

    $header = @{
        "authorization"         = "$authKey";
        "x-ms-version"          = "2018-12-31";
        "Cache-Control"         = "no-cache";
        "x-ms-date"             = "$xDate";
        "Accept"                = "application/json";
        "User-Agent"            = "PowerShell-RestApi-Samples"
    }

    $GetContainerResult = Invoke-RestMethod -Uri $requestUri -Headers $header -Method $verb -ContentType $contentType
    Write-Host "Container $ContainerId Read."
    return $GetContainerResult
    }
    catch{
        Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
        Write-Host "Exception Message:" $_.Exception.Message
        return $_.Exception.Message;  
    }
}

Function Redo-CosmosSQLContainer{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $EndPoint,
        [Parameter(Mandatory)][string] $DatabaseId,
        [Parameter(Mandatory)][string] $ContainerId,
        [Parameter(Mandatory)][string] $MasterKey,
        [Parameter(Mandatory)][string] $KeyType
    )
    #$resourceLink = "dbs/$DatabaseId/colls/$ContainerId"
    #$resourceType = "colls"
    #$contentType = "application/json"
    #$verb = "GET"
   #$date = Get-Date
    #$utcDate = $date.ToUniversalTime()
    #$xDate = $utcDate.ToString('r', [System.Globalization.CultureInfo]::InvariantCulture)
    #$requestUri = "$EndPoint$resourceLink"

    $resultGet = Get-CosmosSQLContainer -EndPoint $EndPoint -DatabaseId $DatabaseId -ContainerId $ContainerId -MasterKey $MasterKey -KeyType $KeyType
<#
    $idxMode = $resultGet.indexingPolicy.indexingMode
    [string]$idxAutomatic = $resultGet.indexingPolicy.automatic.ToString().ToLower()

    $partitionBody = ""
    $idxIncludePathBody = ""
    $idxExcludePathBody = ""
    if ($resultGet.partitionKey.paths.Count -gt 0)
    {
        $partitionKey = $resultGet.partitionKey.paths[0]
        $partitionBody = '"partitionKey": {"paths":["' + $partitionKey + '"]}'
    }

    if ($resultGet.indexingPolicy.includedPaths.Count -gt 0)
    {
        $idxIncludePath = $resultGet.indexingPolicy.includedPaths[0].path
        $idxIncludePathBody = '"includedPaths": [{"path": "' + $idxIncludePath + '"}]'
    }

    if ($resultGet.indexingPolicy.excludedPaths.Count -gt 0)
    {
        $idxExcludePath = $resultGet.indexingPolicy.excludedPaths[0].path
        $idxExcludePathBody = '"excludedPaths": [{"path": "' + ($idxExcludePath -replace '"', '\"') + '"}]'
    }
    $ttl = ''

    if ($resultGet.PSobject.Properties.Name.Contains("defaultTtl"))
    {
        $ttl = '"defaultTtl" : ' + $resultGet.defaultTtl
    }

    $body = @"
{  
        "id": "${ContainerId},
        "indexingPolicy": {  
          "automatic": $idxAutomatic,  
          "indexingMode": "$idxMode",  
          $idxIncludePathBody,
          $idxExcludePathBody
        } ,
        $partitionBody,
        $ttl
}
"@
#>
    $body = ConvertTo-Json -InputObject $resultGet -Depth 100
    $obj = ConvertFrom-Json -InputObject $body

    #remove all underscore properties as they are system properties
    $obj = $obj | Select-Object -Property * -ExcludeProperty _*
    $body = ConvertTo-Json -InputObject $obj -Depth 100

    $resultRemove = Remove-CosmosSQLContainer -EndPoint $EndPoint -DatabaseId $DatabaseId -ContainerId $ContainerId -MasterKey $MasterKey -KeyType $KeyType

    $resultNew = New-CosmosSQLContainer -EndPoint $EndPoint -DatabaseId $DatabaseId -ContainerId $ContainerId -PartitionKey $partitionKey -MasterKey $MasterKey -KeyType $KeyType -ResponseBody $body

    return $resultNew
}



$keyType = "master"
$tokenVersion = "1.0"
$date = Get-Date
$utcDate = $date.ToUniversalTime()
$xDate = $utcDate.ToString('r', [System.Globalization.CultureInfo]::InvariantCulture)

#User Input
$endpoint = "https://kpcsdbahadevuws2mhw1.documents.azure.com:443/"
$masterKey = "n80iztOmqAJllZvFJ7RQI3RyJC9PENbwMXZ9O6MSnyFT7IZbZtICOvJrclLl8tFG1w0iVLmBupHruF6rRJmMyw=="
$databaseId = "dbDFC"
$containerId = "paperless-interrupt"
$partitionKey = "/id"   #should start with a /
$contTTL = $null # '-1'

################## ONLY 1 MEHTOD BELOW SHOULD  BE UNCOMMENTED #########################

#$result = New-CosmosSQLDatabase -EndPoint $endpoint -DatabaseId $databaseId -MasterKey $MasterKey -KeyType $keyType
#$result = Remove-CosmosSQLDatabase -EndPoint $endpoint -DatabaseId $databaseId -MasterKey $masterKey -KeyType $keyType
#$result = Remove-CosmosSQLContainer -EndPoint $endpoint -DatabaseId $databaseId -ContainerId $containerId -MasterKey $masterKey -KeyType $keyType
$result = New-CosmosSQLContainer -EndPoint $endpoint -DatabaseId $databaseId -ContainerId $containerId -PartitionKey $partitionKey -MasterKey $masterKey -KeyType $keyType -ttlValue $contTTL

#$result = Get-CosmosSQLContainer -EndPoint $endpoint -DatabaseId $databaseId -ContainerId $containerId -MasterKey $masterKey -KeyType $keyType
#$result = Get-CosmosSQLDatabase -EndPoint $endpoint -DatabaseId $databaseId -MasterKey $MasterKey -KeyType $keyType
#$result = Redo-CosmosSQLContainer -EndPoint $endpoint -DatabaseId $databaseId -ContainerId $containerId -MasterKey $masterKey -KeyType $keyType
Write-Host ($result | ConvertTo-Json -Depth 100)
